"use strict";
const fs = require("fs");
const request = require("request");
function httpRequest(url) {
    return new Promise((resolve, reject) => {
        request(url, (error, response, body) => {
            if (error) {
                reject(error);
            }
            else if (response.statusCode !== 200) {
                reject(response.statusCode);
            }
            else {
                resolve(body);
            }
        });
    });
}
exports.httpRequest = httpRequest;
function readFile(fileName) {
    return new Promise((resolve, reject) => {
        fs.readFile(fileName, 'utf8', (error, data) => {
            error ? reject(error) : resolve(data);
        });
    });
}
exports.readFile = readFile;
//# sourceMappingURL=promisified-io.js.map