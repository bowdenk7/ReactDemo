"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const promisified_io_1 = require("./promisified-io");
const express = require("express");
function getRedditFeed(subreddit) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return yield promisified_io_1.httpRequest(`http://reddit.com/r/${subreddit}.json`);
        }
        catch (e) {
            return yield promisified_io_1.readFile("data.json");
        }
    });
}
let app = express();
app.get("/r/aww.json", (req, res) => {
    getRedditFeed("aww")
        .then(body => { res.json(body); })
        .catch(err => console.error(err));
});
//app.use("/", express.static(__dirname + "/../../react-reddit-reader"));
const server = app.listen(8000, () => {
    console.log("Server listening on port 8000");
});
//# sourceMappingURL=server.js.map