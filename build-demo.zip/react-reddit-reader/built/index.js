"use strict";
var jQuery = require("jquery");
var React = require("react");
var ReactDOM = require("react-dom");
var RedditSubmission_1 = require("./components/RedditSubmission");
function displaySubreddit(subreddit) {
    jQuery.ajax({ url: "/r/" + subreddit + ".json" }).done(function (response) {
        var submissions = response.data.children;
        // Only take submissions that link directly to png and jpg files. 
        submissions = submissions.filter(function (_a) {
            var data = _a.data;
            return /(png|jpg)$/.test(data.url);
        });
        // Create our list of components.
        var components = submissions
            .map(function (value, index) { return React.createElement(RedditSubmission_1.SubmissionComp, React.__spread({key: index, elementPosition: index}, value.data)); });
        ReactDOM.render(React.createElement("div", null, components), document.getElementById("content"));
    });
}
displaySubreddit("aww");
//# sourceMappingURL=index.js.map