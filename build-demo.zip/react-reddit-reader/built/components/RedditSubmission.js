"use strict";
var React = require("react");
var imageStyle = {
    maxWidth: "600px",
    maxHeight: "600px",
};
exports.SubmissionComp = function (submission) {
    return React.createElement("div", {style: { fontFamily: "sans-serif" }}, submission.elementPosition ? React.createElement("br", null) : "", React.createElement("span", {style: { fontSize: "1.2rem" }}, React.createElement("span", null, submission.elementPosition + 1, ". "), React.createElement("a", {href: submission.url}, submission.title)), React.createElement("span", null, " (", submission.domain, ")"), React.createElement("div", null, "Submitted by ", submission.author, "."), React.createElement("br", null), React.createElement("img", {src: submission.url, style: imageStyle}));
};
//# sourceMappingURL=RedditSubmission.js.map